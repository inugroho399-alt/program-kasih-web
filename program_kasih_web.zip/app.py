from flask import Flask, render_template, request, send_file, redirect, url_for
import io
try:
    from reportlab.pdfgen import canvas
except Exception:
    canvas = None

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/preview', methods=['POST'])
def preview():
    # collect form data and render a printable HTML nota
    data = {
        'nama': request.form.get('nama', '').strip(),
        'alamat': request.form.get('alamat', '').strip(),
        'telepon': request.form.get('telepon', '').strip(),
        'items': []
    }

    # items sent as item_name[], qty[], price[]
    names = request.form.getlist('item_name[]')
    qtys = request.form.getlist('item_qty[]')
    prices = request.form.getlist('item_price[]')

    total = 0.0
    for n, q, p in zip(names, qtys, prices):
        try:
            qn = int(q)
        except:
            qn = 1
        try:
            pp = float(p)
        except:
            pp = 0.0
        subtotal = qn * pp
        total += subtotal
        data['items'].append({'name': n, 'qty': qn, 'price': pp, 'subtotal': subtotal})

    data['total'] = total
    return render_template('nota.html', data=data)

@app.route('/download_pdf', methods=['POST'])
def download_pdf():
    if canvas is None:
        return "reportlab not installed on the server. Install with: pip install reportlab", 500

    # Generate same data processing as preview
    names = request.form.getlist('item_name[]')
    qtys = request.form.getlist('item_qty[]')
    prices = request.form.getlist('item_price[]')
    nama = request.form.get('nama', '')
    alamat = request.form.get('alamat', '')
    telepon = request.form.get('telepon', '')

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer)
    y = 800
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(50, y, "Nota Pembelian - Program Kasih")
    y -= 30
    pdf.setFont('Helvetica', 10)
    pdf.drawString(50, y, f"Nama: {nama}")
    y -= 15
    pdf.drawString(50, y, f"Alamat: {alamat}")
    y -= 15
    pdf.drawString(50, y, f"Telepon: {telepon}")
    y -= 25

    pdf.drawString(50, y, "No")
    pdf.drawString(90, y, "Item")
    pdf.drawString(350, y, "Qty")
    pdf.drawString(400, y, "Harga")
    pdf.drawString(480, y, "Subtotal")
    y -= 15

    total = 0.0
    idx = 1
    for n, q, p in zip(names, qtys, prices):
        try:
            qn = int(q)
        except:
            qn = 1
        try:
            pp = float(p)
        except:
            pp = 0.0
        subtotal = qn * pp
        pdf.drawString(50, y, str(idx))
        pdf.drawString(90, y, str(n)[:40])
        pdf.drawString(350, y, str(qn))
        pdf.drawString(400, y, f"{pp:.2f}")
        pdf.drawString(480, y, f"{subtotal:.2f}")
        y -= 15
        idx += 1
        total += subtotal
        if y < 80:
            pdf.showPage()
            y = 800

    y -= 10
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(400, y, "Total:")
    pdf.drawString(480, y, f"{total:.2f}")

    pdf.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name='nota_program_kasih.pdf', mimetype='application/pdf')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
