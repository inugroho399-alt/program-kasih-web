Program Kasih - Web Nota (Flask)
Files:
  - app.py
  - templates/index.html
  - templates/nota.html
  - static/style.css

Cara menjalankan (di mesin lokal):
1. Pastikan Python 3.8+ terpasang.
2. Buat virtualenv (opsional) dan aktifkan:
   python -m venv venv
   source venv/bin/activate   (Linux/macOS)
   venv\Scripts\activate    (Windows)
3. Install dependencies:
   pip install flask reportlab
   (reportlab diperlukan hanya jika ingin enable fitur 'Download PDF')
4. Jalankan:
   python app.py
5. Buka browser ke: http://127.0.0.1:5000

Penjelasan singkat:
- Halaman utama berisi form untuk memasukkan data pelanggan dan item.
- Tombol 'Preview Nota' akan menampilkan nota dalam format HTML.
- Di halaman preview ada tombol Print (menggunakan browser) dan Download PDF (server-side dengan reportlab).
